// Debug tracing: per-turn branch tags and fuel checkpoints (TRACE).
use std::fmt::Write as _;

// Verbose turn/fuel tracing is disabled; farm-target changes have their own concise diagnostic.
pub const TRACE: bool = false;
pub(super) const FARM_TARGET_DIAGNOSTICS: bool = true;
// With TRACE: print only turns that ran out of fuel (a checkpoint shows more fuel than the one
// before it: the turn was cut off and carried on into the next) or used at least SPILL_TRACE_FUEL.
// Formatting every turn's trace costs enough fuel to cause cut-offs of its own.
pub const TRACE_ONLY_SPILLS: bool = true;
// Profiling: the caching fuel fixes (rally decision, camp-fight verdicts, path fields) also work the
// answer out afresh and trace "<cache>-mismatch" when the cached one differs. Costs the fuel the
// caches save, so only for measuring how often they're wrong.
pub const VERIFY_FUEL_CACHES: bool = false;
const SPILL_TRACE_FUEL: u64 = 90_000;

thread_local! {
    static TRACE_TAGS: std::cell::RefCell<String> = const { std::cell::RefCell::new(String::new()) };
}

// Tags and checkpoints are profiling only: in a debug_block they cost no fuel in local debug
// builds, and the platform's release build skips them.
pub fn trace(tag: &'static str) {
    cambc::debug_block! {
        super::activity::note(tag);
        if TRACE {
            TRACE_TAGS.with(|t| {
                let mut t = t.borrow_mut();
                t.push(' ');
                t.push_str(tag);
            });
        }
    }
}

thread_local! {
    static CHECKPOINTS: std::cell::RefCell<Vec<(&'static str, u64)>> = const { std::cell::RefCell::new(Vec::new()) };
}

// Record fuel left at a point in the turn (formatted only when the trace is printed, so the
// measurement itself costs little).
#[allow(dead_code)] // for profiling: sprinkle in, read the trace, remove
pub fn checkpoint(tag: &'static str) {
    if TRACE {
        let fuel = cambc::fuel_remaining().unwrap_or(0);
        cambc::debug_block! {
            CHECKPOINTS.with(|c| c.borrow_mut().push((tag, fuel)));
        }
    }
}

// Whether this turn's trace should be printed (see TRACE_ONLY_SPILLS); if not, it's dropped.
pub fn trace_wanted() -> bool {
    if !TRACE_ONLY_SPILLS {
        return true;
    }
    let wanted = CHECKPOINTS.with(|c| {
        let c = c.borrow();
        let spilled = c.windows(2).any(|w| w[1].1 > w[0].1);
        let used = match (c.first(), c.last()) {
            (Some(first), Some(last)) => first.1.saturating_sub(last.1),
            _ => 0,
        };
        spilled || used >= SPILL_TRACE_FUEL
    });
    if !wanted {
        TRACE_TAGS.with(|t| t.borrow_mut().clear());
        CHECKPOINTS.with(|c| c.borrow_mut().clear());
    }
    wanted
}

pub fn take_trace() -> String {
    let mut out = TRACE_TAGS.with(|t| std::mem::take(&mut *t.borrow_mut()));
    let checkpoints = CHECKPOINTS.with(|c| std::mem::take(&mut *c.borrow_mut()));
    if !checkpoints.is_empty() {
        out.push_str(" | fuel[k left]: ");
        let mut previous = None;
        for (tag, fuel) in checkpoints {
            if let Some(before) = previous {
                if fuel > before {
                    write!(out, " -> next turn: {tag} {}k", fuel / 1000)
                        .expect("writing to String cannot fail");
                } else {
                    let change = (fuel as i64 - before as i64) / 1000;
                    write!(out, " -> {tag} {}k ({change:+}k)", fuel / 1000)
                        .expect("writing to String cannot fail");
                }
            } else {
                write!(out, "{tag} {}k", fuel / 1000).expect("writing to String cannot fail");
            }
            previous = Some(fuel);
        }
    }
    out
}
